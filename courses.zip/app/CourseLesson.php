<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class CourseLesson extends Model
{
    protected $table = "course_lesson";
    
}
