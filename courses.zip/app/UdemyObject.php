<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class UdemyObject extends Model
{
    
}
