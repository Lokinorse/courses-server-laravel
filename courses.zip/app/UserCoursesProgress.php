<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class UserCoursesProgress extends Model
{
    protected $table = "user_courses_progress";
}
