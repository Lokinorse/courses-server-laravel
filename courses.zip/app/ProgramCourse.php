<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class ProgramCourse extends Model
{
    protected $table = "program_course";
}
