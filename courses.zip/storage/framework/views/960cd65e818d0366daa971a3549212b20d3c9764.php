<?php $__env->startComponent('components.modal'); ?>
    
    <?php $__env->slot('modal_id', 'lessontest'); ?>
    <?php $__env->slot('modal_max_height', '400px'); ?>
    <?php $__env->slot('modal_max_width', '700px'); ?>

    
    <?php $__env->slot('modal_header', 'Тестирование знаний'); ?>

    <?php $__env->slot('modal_content',""); ?>



    <?php $__env->slot('modal_footer'); ?>
        <div class="actions-group pull-left">
        </div>
    <?php $__env->endSlot(); ?>
<?php echo $__env->renderComponent(); ?>