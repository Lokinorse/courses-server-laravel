<div id="<?php echo e($row->field); ?>" data-theme="<?php echo e(@$options->theme); ?>" data-language="<?php echo e(@$options->language); ?>" class="ace_editor min_height_200" name="<?php echo e($row->field); ?>">
    <?php echo e($dataTypeContent->{$row->field} ?? old($row->field) ?? $options->default ?? ''); ?>

</div>
<textarea name="<?php echo e($row->field); ?>" id="<?php echo e($row->field); ?>_textarea" class="hidden"><?php echo e($dataTypeContent->{$row->field} ?? old($row->field) ?? $options->default ?? ''); ?></textarea>
