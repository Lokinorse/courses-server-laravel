<?php
    $messages = $messages->sortByDesc('id');
?>

<?php if($messages->count() < 1): ?>

    <div class="empty-chat">
        Не было задано ни одного вопроса
        <br/>
        Стань первым!
    </div>

<?php endif; ?>


<?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php
        $user = $message->user()->first();    
        $childMessages = $message->childs()->get();
    ?>

    <div class="message-wrapper">
        <div class="avatar-thumb">
            <img src="<?php echo e($user->avatar); ?>"/>
        </div>
        <div class="message-content">
            <div class="message-badge">
                <div class="message-header">
                    <a target="_blank" href="https://vk.com/id<?php echo e($user->provider_user_id); ?>"><img src="<?php echo e(asset("img/vk_logo.png")); ?>"/> <?php echo e($user->name); ?></a>
                    <span class="message-date"><?php echo e($message->humanDiff()); ?></span>
                </div>
                <div class="message-text">
                    <?php echo e($message->text); ?>            
                </div>
                <div class="message-actions-wrapper">
                    <button class="make_reply" data-messagetype="comment" data-messageid="<?php echo e($message->id); ?>" data-author="<?php echo e($user->name); ?>">ответить</button>
                </div>
            </div>
            <?php if($childMessages->count() > 0 ): ?>
                <span class="reply"><i class="fa fa-level-down-alt"></i> в ответ</span>
                <?php echo $__env->make('components.chat', ['messages'=>$childMessages], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>
        </div>
    </div>
    
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>