<?php $__env->startSection('content'); ?>
<div class="container cabinet-room">
    
    <div class="row">
        <div class="col-md-12 cabinet-user-header">
            <h1>Личный кабинет</h1>
            <div class="balance-inner-wrapper">

                <?php if(!Auth::user()->isPromoUsed(env("CURRENT_PROMO_ID"))): ?> 
                    <div class="giftcard" data-modaltrigger="promocode">
                        <i class="fa fa-gift"></i> Получить 20 000 на счет
                    </div>
                <?php endif; ?>

                <div class="balance-count">
                    <span class="balance-label">Твой баланс: </span> <?php echo e(Auth::user()->balance); ?> рублей
                </div>
            </div>
            
        </div>
    </div>

    <div class="row">
        <div class="col-md-12">
            <h2>Программы</h2>
        </div>
        <div class="col-md-12">

            <div class="container cabinet-programs">
                <div class="row">
                    <?php $__currentLoopData = $units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <div class="cabinet-program-wrapper col-md-12">
                            <div class="cabinet-program-thumb" style="background-image: url(<?php echo e(url("storage/".$unit->thumb)); ?>)"></div>
                            <div class="cabinet-program-content">
                                <h2 class="cabinet-program-title"><?php echo e($unit->name); ?></h2>
                                <div class="cabinet-program-description"><?php echo $unit->description; ?></div>
                                <div class="cabinet-program-footer">
                                    <?php if(Auth::user()->isUnitPurchased($unit->id)): ?>
                                        <a href="<?php echo e($unit->slug); ?>" class="cabinet-program-cta">
                                            <i class="fa fa-play"></i>
                                            <div class="cabinet-program-action-text">
                                                <span>
                                                    К обучению
                                                </span>
                                            </div>
                                        </a>
                                    <?php else: ?> 
                                        <?php
                                            $modalId = "unlock-".$unit->id;
                                        ?>
                                        <button class="cabinet-program-cta" data-modaltrigger="<?php echo e($modalId); ?>">
                                                <i class="fa fa-unlock"></i>
                                            <div class="cabinet-program-action-text">
                                                <div class="cabinet-program-price">
                                                    Стоимость: <?php echo e($unit->cost); ?>р.
                                                </div>
                                                <span>
                                                    Разблокировать
                                                </span>
                                            </div>
                                        </button>
                                        <?php echo $__env->make("cabinet.modals.paymodal", ["unit" => $unit], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>

    </div>
</div>

<?php if(!Auth::user()->isPromoUsed(env("CURRENT_PROMO_ID"))): ?> 
    <?php echo $__env->make("cabinet.modals.promocode", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>


<?php if(session()->get('message_modal')): ?>
    <?php echo $__env->make("cabinet.modals.infomodal", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>