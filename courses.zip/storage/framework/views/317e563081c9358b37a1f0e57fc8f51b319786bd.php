<div class="lesson-pane communication-tabs">
    <div class="tab-headers">
        <div class="tab-pill active" id="comments">Комментарии</div>
        <div class="tab-pill" id="faq">Задать вопрос по уроку</div>
    </div>

    <script>var chat_target_id = <?php echo e($lesson->id); ?>;</script>
    <div class="lesson-pane-content tab-content active" data-tabtarget="comments">
        <div id="unit-chat" class="chat-wrapper">
            <?php if(Auth::user()): ?> 
                <div class="chat-input">
                    <input class="message-input" placeholder="Напиши сюда свое сообщение"/>
                    <button class="send-chat-message main-button">Написать</button>
                </div>
            <?php endif; ?>
            <div class="chat-messages"></div>
        </div>
    </div>    
    <div class="lesson-pane-content tab-content" data-tabtarget="faq">
        <div id="unit-faq" class="chat-wrapper">
            <?php if(Auth::user()): ?> 
                <div class="chat-input">
                    <input class="message-input" placeholder="Впиши сюда свой вопрос"/>
                    <button class="send-chat-message main-button">Задать вопрос</button>
                </div>
            <?php endif; ?>
            <div class="chat-messages"></div>
        </div>
    </div>  
</div>

<?php echo $__env->make("program.modals.answer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>