<input type="hidden" class="form-control" name="<?php echo e($row->field); ?>"
       placeholder="<?php echo e($row->display_name); ?>"
       <?php echo isBreadSlugAutoGenerator($options); ?>

       value="<?php echo e($dataTypeContent->{$row->field} ?? old($row->field) ?? $options->default ?? ''); ?>">
