<?php $__env->startComponent('components.modal'); ?>
    
    <?php $__env->slot('modal_id', 'vk-login'); ?>
    <?php $__env->slot('modal_max_height', '300px'); ?>
    <?php $__env->slot('modal_max_width', '700px'); ?>

    
    <?php $__env->slot('modal_header', 'Начало обучения'); ?>

    <?php $__env->slot('modal_content'); ?>

            <a class="main-button" href="<?php echo e(url('auth/vkontakte')); ?>">
                <img src="<?php echo e(asset("img/vk_logo.png")); ?>"/>
            </a>
            Чтобы начать обучение, необходимо войти на платформу с помощью вконтакте.

    <?php $__env->endSlot(); ?>

    <?php $__env->slot('modal_footer'); ?>
        <div class="actions-group pull-left">
            <a class="modal-actions main-button" href="<?php echo e(url('auth/vkontakte')); ?>">Войти с помощью Вконтакте</a>
        </div>
    <?php $__env->endSlot(); ?>

<?php echo $__env->renderComponent(); ?>

