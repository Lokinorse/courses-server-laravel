<?php $__env->startComponent('components.modal'); ?>
    
    <?php $__env->slot('modal_id', 'answermodal'); ?>
    <?php $__env->slot('modal_max_height', '400px'); ?>
    <?php $__env->slot('modal_max_width', '700px'); ?>

    
    <?php $__env->slot('modal_header', 'Ответ на сообщение'); ?>

    <?php $__env->slot('modal_content'); ?>
        <textarea class="answer-area"></textarea>
    <?php $__env->endSlot(); ?>
    <?php $__env->slot('modal_footer'); ?>
        <div class="actions-group pull-left">
            <button class="main-button">Ответить</button>
        </div>
    <?php $__env->endSlot(); ?>
<?php echo $__env->renderComponent(); ?>