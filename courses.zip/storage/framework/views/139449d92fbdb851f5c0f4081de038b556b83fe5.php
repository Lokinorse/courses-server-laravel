<footer>
	<div class="lp-content">
		<img class="white-logo" src="<?php echo e(asset('img/jslp/white-logo.png')); ?>" alt="Varilo.ru" />
		<div class="copyright"><?php echo e(now()->year); ?>г. Все права защищены. Любое копирование материалов сайта преследуется по закону.</div>
	</div>
</footer>