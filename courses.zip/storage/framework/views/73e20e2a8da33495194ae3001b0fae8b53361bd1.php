<br>
<?php $checked = false; ?>
<?php if(isset($options->options)): ?>
    <?php $__currentLoopData = $options->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(isset($dataTypeContent->{$row->field}) || old($row->field)): ?>
            <?php $checked = old($row->field, $dataTypeContent->{$row->field}); ?>
        <?php else: ?>
            <?php $checked = isset($options->checked) && $options->checked ? true : false; ?>
        <?php endif; ?>

        <input type="checkbox" name="<?php echo e($row->field); ?>[<?php echo e($key); ?>]"
               <?php echo $checked ? 'checked="checked"' : ''; ?> value="<?php echo e($key); ?>" />
        <?php echo e($label); ?>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
