<nav class="varilo-nav grey padded">
    <div class="nav-content">

        <div class="logo-row">
            
            
            <a class="navbar-brand" href="<?php echo e(url('/')); ?>">              
                <img class="logo" src="<?php echo e(asset('img/logo.png')); ?>" alt="<?php echo e(config('app.name', 'Laravel')); ?>" />
            </a>

            <button class="mobile-hamb"><i class="fa"></i></button>
        </div>



        <div class="nav-collapse-wrapper">
            <div></div>
            <?php echo $__env->yieldContent('landing-nav'); ?>
            <div class="nav-right-side navbar-list">

                <?php if(auth()->guard()->guest()): ?>
                    <div class="navbar-list-item">
                        <a class="nav-link" href="<?php echo e(url('auth/vkontakte')); ?>">Войти через VK</a>
                    </div>
                <?php else: ?>
                    <?php if(Auth::user()->hasRole('admin')): ?> 
                        <div class="navbar-list-item">
                            <a class="nav-link" href="<?php echo e(url('admin')); ?>">
                                Админка
                            </a>
                        </div>
                    <?php endif; ?>
                    <div class="navbar-list-item">
                        <a class="nav-link" href="<?php echo e(route('cabinet')); ?>">
                            <img src=<?php echo e(Auth::user()->avatar); ?>/>
                            В кабинет
                        </a>
                    </div>
                    <div class="navbar-list-item">
                        <a class="nav-link" href="<?php echo e(route('logout')); ?>"
                           onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                            Выход
                        </a>
                    </div>
                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                        <?php echo csrf_field(); ?>
                    </form>
                <?php endif; ?>


            </div>
        </div>


    </div>
</nav>


