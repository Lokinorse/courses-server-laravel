<?php if($message_type == "comment"): ?>
    <?php echo $__env->make('components.comments', compact('messages'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php else: ?>     
    <?php echo $__env->make('components.faq', compact('messages'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>

