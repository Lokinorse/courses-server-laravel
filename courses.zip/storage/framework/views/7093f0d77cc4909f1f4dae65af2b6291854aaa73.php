<ol class="dd-list">

<?php

    $items = $item->orderedChilds()->get()->sortByDesc(function ($item, $key) {
        return $item->id;
    })->sortBy(function ($item, $key) {
        return $item->pivot->order;
    });

?>



<?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <?php
        $isActive = null;
        $styles = null;
               

        switch ($child->unit_type) {
            case 1:
                # "1": "Курс",
                $icon = "voyager-book";
                $unit_type_text = "Курс";
                break;
            case 2:
                # "2": "Глава",
                $icon = "voyager-folder";
                $unit_type_text = "Глава";
                break;
            case 3:
                # "3": "Урок"
                $icon = "voyager-file-text";
                $unit_type_text = "Урок";
                break;
            default:
                $icon = "voyager-study";
                $unit_type_text = "Программа";
                break;
        }


        
    ?>

        <li class="dd-item" data-id="<?php echo e($child->id); ?>">
        <div class="pull-right item_actions">
            <div class="btn btn-sm btn-danger pull-right content_item_delete" data-id="<?php echo e($child->id); ?>">
                <i class="voyager-trash"></i> <?php echo e(__('voyager::generic.delete')); ?>

            </div>
            <a href="<?php echo e(url('admin/units/'.$child->id.'/edit')); ?>" class="btn btn-sm btn-primary pull-right edit">
                <i class="voyager-edit"></i> <?php echo e(__('voyager::generic.edit')); ?>

            </a>
        </div>
        <div class="dd-handle">
            <i class="<?php echo e($icon); ?>"></i>
            <span><?php echo e($child->id); ?> <?php echo e($unit_type_text); ?> <?php echo e($child->name); ?> <?php echo e($child->pivot->order); ?></span>
        </div>

        <?php echo $__env->make('vendor.voyager.units.list', ['item' => $child], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </li>


<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</ol>