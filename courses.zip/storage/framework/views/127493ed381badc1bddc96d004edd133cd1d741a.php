<?php $__env->startSection('content'); ?>
	<?php echo $__env->make("landing.matrix", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<?php echo $__env->make("landing.advantages", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<?php echo $__env->make("landing.program", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<?php echo $__env->make("landing.starter", ["position" => 0], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<?php echo $__env->make("landing.resume", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<?php echo $__env->make("landing.teacher", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<?php echo $__env->make("landing.starter", ["position" => 1], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<?php echo $__env->make("landing.faq", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<?php echo $__env->make("landing.starter", ["position" => 2], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<?php echo $__env->make("landing.footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make("landing.modals.vk-login", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('landing-nav'); ?>
    <div class="nav-left-side navbar-list">

        <div class="navbar-list-item">
            <a class="nav-link" href="/#advantages">Преимущества</a>
        </div>
        <div class="navbar-list-item">
            <a class="nav-link" href="/#program">Программа</a>
        </div>
        <div class="navbar-list-item">
            <a class="nav-link" href="/#teacher">Преподаватель</a>
        </div>
        <div class="navbar-list-item">
            <a class="nav-link" href="/#faq">FAQ</a>
        </div>
        <div class="navbar-list-item">
            
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.landing', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>