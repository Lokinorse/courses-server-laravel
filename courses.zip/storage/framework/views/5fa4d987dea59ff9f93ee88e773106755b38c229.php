<?php $__currentLoopData = $menu->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $menuItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <?php
        $isActive = null;
        $styles = null;
        
        $child = $menuItem->first();
        
        $childMenu = $menuItem->last();

        $href = "#child".$child->id;
        $isLesson = false;
        switch ($child->unit_type) {
            case 1:
            # "1": "Курс",
                $icon = "graduation-cap";
                $unit_type_text = "Курс";
                $unit_class = "unit-course";
            break;
            case 2:
            # "2": "Глава",
                $icon = "book";
                $unit_type_text = "Раздел";
                $unit_class = "unit-chapter";
                break;
            case 3:
                # "3": "Урок"
                $icon = "play-circle";
                $unit_type_text = "Урок";
                $href = url($program->slug."/".$child->slug);
                $isLesson = true;
                $unit_class = "unit-lesson";
                
                break;
            default:
                $icon = "voyager-study";
                $unit_type_text = "Программа";
                $unit_class = "unit-program";
                break;
        }

        $currentLessonStatus = $child->getStatus($progress);
        
        $progressBadge = null; 
        switch ($currentLessonStatus) {
            case -1:
                $progressBadge = "unlock";
            break;
            case -2:
                $progressBadge = "hourglass-half";
            break;
            case -3:
                $progressBadge = "lock";
            break;
            case 0:
                $progressBadge = "arrow-right";
            break;
            case 1:
                $progressBadge = "check-circle";
            break;
            case 2:
                $progressBadge = "check-double";
            break;
            case 3:
                $progressBadge = "hourglass-half";
            break;
            default:
                $progressBadge = null;
            break;
        }

        

        $isActive = $child->slug == $lesson->slug;
    
        $isPathPart = collect($breadcrumbs)->contains($child->id);
        
    ?>

<div class="unit-block <?php echo e($unit_class); ?>">
    <?php if($isLesson): ?>
        <a class="unit <?php if($isActive): ?> active <?php endif; ?>" href="<?php echo e($href); ?>">
            <span>
                <span class="fa fa-<?php echo e($icon); ?>" aria-hidden="true"></span>
                <?php echo e($key + 1); ?> <?php echo e($child->name); ?>

            </span>
            <?php if($progressBadge): ?> <span class="<?php echo e($progressBadge); ?> unit-badge fa fa-<?php echo e($progressBadge); ?>"></span> <?php endif; ?>
        </a>
    <?php else: ?> 
        <div class="unit <?php if(!$isPathPart): ?> collapsed <?php endif; ?>" data-toggle="collapse" href="<?php echo e($href); ?>" role="button">
            <span>
                <span class="fa fa-chevron-right" aria-hidden="true"></span>
                <?php echo e($child->name); ?>

            </span>
        </div>
        <?php if(isset($childMenu) && $childMenu->count() > 0): ?>
        <div class="collapse nav-chapter-list-wrapper <?php if($isPathPart): ?> show <?php endif; ?>" id="child<?php echo e($child->id); ?>">
            <?php echo $__env->make('program.lesson-menu', ['menu' => $childMenu, 'progress' => $progress, 'lesson' => $lesson], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <?php endif; ?>
    <?php endif; ?> 
            
</div>



<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>