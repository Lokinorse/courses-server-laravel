<?php $__env->startComponent('components.modal'); ?>
    
    <?php $__env->slot('modal_id', 'unlock-'.$unit->id); ?>
    <?php $__env->slot('modal_max_height', '300px'); ?>
    <?php $__env->slot('modal_max_width', '700px'); ?>

    
    <?php $__env->slot('modal_header', 'Подтверждение разблокировки'); ?>

    <?php $__env->slot('modal_content'); ?>
            <span>
                Я рад, что ты всерьез решил подойти к делу! 
                <br/>
                После подтверждения, с твоего счета в <b>платформе</b> спишется <b><?php echo e($unit->cost); ?></b> рублей.
            </span>
    <?php $__env->endSlot(); ?>

    <?php $__env->slot('modal_footer'); ?>
        <div class="actions-group pull-left">
            <a class="modal-actions main-button" href="<?php echo e(url('/purchase/'.$unit->id)); ?>">Подтвердить и разблокировать</a>
        </div>
    <?php $__env->endSlot(); ?>
<?php echo $__env->renderComponent(); ?>