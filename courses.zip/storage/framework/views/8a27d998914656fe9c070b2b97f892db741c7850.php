<?php 
    $modal = (object) json_decode(session()->get('message_modal'));
?>

<?php $__env->startComponent('components.modal'); ?>
    <?php $__env->slot('modal_id', 'infomodal'); ?>
    <?php $__env->slot('modal_max_height', '300px'); ?>
    <?php $__env->slot('modal_max_width', '700px'); ?>

    <?php if(isset($modal->header)): ?>
        <?php $__env->slot('modal_header'); ?>
            <?php echo $modal->header; ?>

        <?php $__env->endSlot(); ?>
    <?php endif; ?>

    <?php if(isset($modal->content)): ?>
        <?php $__env->slot('modal_content'); ?>
            <?php echo $modal->content; ?>

        <?php $__env->endSlot(); ?>
    <?php endif; ?>

    <?php if(isset($modal->footer)): ?>
        <?php $__env->slot('modal_footer'); ?>
            <?php echo $modal->footer; ?>

        <?php $__env->endSlot(); ?>
    <?php endif; ?>
<?php echo $__env->renderComponent(); ?>






