<template id="<?php echo e($modal_id); ?>">
    <div class="modal-wrapper modal-<?php echo e($modal_id); ?>" data-modal="<?php echo e($modal_id); ?>">
        <div class="modal-inner-content" style="max-height: <?php echo e($modal_max_height); ?>; max-width: <?php echo e($modal_max_width); ?>; ">
            
            <div class="modal-header">
                <?php if(isset($modal_header)): ?>
                    <?php echo e($modal_header); ?> 
                <?php endif; ?>
                <div data-modalclose="<?php echo e($modal_id); ?>"><i class="fa fa-times"></i></div>
            </div>

            <?php if(isset($modal_content)): ?>
                <div class="modal-content"><?php echo e($modal_content); ?></div> 
            <?php endif; ?>
            <?php if(isset($modal_footer)): ?>
                <div class="modal-footer"><?php echo e($modal_footer); ?></div>
            <?php endif; ?>
        </div>
    </div>
</template>