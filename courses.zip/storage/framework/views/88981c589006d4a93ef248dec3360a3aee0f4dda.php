<?php 
    $videos = json_decode($lesson->videos);
    $videoURL = null;
    if (isset($videos[0])) $videoURL = url("storage/".json_decode($lesson->videos)[0]);


    $content = $lesson->description;
    if (trim($content) == "") $content = null;

    $currentLessonStatus = $lesson->getStatus($progress);
?>

<?php switch($currentLessonStatus):
    case (-3): ?>
        <?php echo $__env->make('program.lesson-states.locked', [ "program" => $program ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php break; ?>
    
    <?php case (-2): ?>
        <?php echo $__env->make('program.lesson-states.in-creation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php break; ?>

    <?php default: ?>
        <?php echo $__env->make('program.lesson-states.opened', [
            "lesson" => $lesson, 
            "status" => $currentLessonStatus, 
            "program" => $program
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endswitch; ?>

