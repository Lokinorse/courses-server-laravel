<input type="color" class="form-control" name="<?php echo e($row->field); ?>"
       value="<?php echo e($dataTypeContent->{$row->field} ?? old($row->field)); ?>">
