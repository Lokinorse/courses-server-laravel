<?php $__env->startSection('content'); ?>

<script>
    var currentUnit = <?php echo json_encode($lesson); ?>

    var currentProgram = <?php echo json_encode($program); ?>

</script>

<div class="container cabinet-room">
    <div class="row">
        <div class="col-md-12">
        <h1 class="program-name"><?php echo e($program->name); ?></h1>
        </div>
        <?php if(Auth::user()): ?>
            <div class="col-md-12">
                <div class="progress">
                    <div class="progress-bar" style="width: <?php echo e($percentProgress); ?>%" role="progressbar" aria-valuenow="10" aria-valuemin="0" aria-valuemax="100"></div>
                </div>
            </div>
            <div class="col-md-12">
                <label class="progresslabel">Прогресс: <?php echo e(round($percentProgress)); ?>%</label>
            </div>
        <?php endif; ?>

    </div>
    <div class="row program-content-wrapper justify-content-center">


        <div class="col-md-4">
            <div class="program-section-header">Содержание</div>
            <div class="program-menu">
                <?php echo $__env->make("program.lesson-menu", compact('menu', 'program', 'progress', 'lesson', 'breadcrumbs'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
        
        <div class="col-md-8">
            <h2 class="program-section-header">Урок: <?php echo e($lesson->name); ?></h2>
            <?php echo $__env->make("program.lesson-content", compact('lesson', 'progress', 'program'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
</div>



<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>