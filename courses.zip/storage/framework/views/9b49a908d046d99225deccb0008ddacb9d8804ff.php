<div class="lesson-pane">
    <h5>Урок закрыт</h5>
    <?php if(Auth::user()): ?>
        <div class="lesson-pane-content">
            Не расстраивайся, ведь чтобы его открыть, тебе всего лишь нужно пройти его предшественников! 
        </div>
        <div class="lesson-pane-footer">
            <a class="main-button" href="<?php echo e(url($program->slug)); ?>">Перейти к текущему уроку</a>
        </div>
    <?php else: ?> 
        <div class="lesson-pane-content">
            Для начала стоит авторизоваться на платформе. Только так я смогу определить, открыт ли конкретно тебе этот урок.
        </div>
        <div class="lesson-pane-footer">
            <a class="main-button" href="<?php echo e(route('oauth', ["vkontakte"])); ?>">Авторизоваться</a>
        </div>
    <?php endif; ?>

</div>