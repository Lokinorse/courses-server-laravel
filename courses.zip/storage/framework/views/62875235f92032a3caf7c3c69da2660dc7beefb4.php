<ol class="dd-list">

        <?php
            $questions = $questions->sortBy(function ($item, $key) {
                return $item->order;
            });
        ?>
        
        
        
        <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
            <li class="dd-item question-item" data-id="<?php echo e($question->id); ?>">
                <div class="pull-right item_actions">
                    <div class="btn btn-sm btn-danger pull-right question_item_delete" data-id="<?php echo e($question->id); ?>">
                        <i class="voyager-trash"></i>
                    </div>
                </div>
                <div class="form-input pull-left">
                    <form class="test-item-change" data-type="question" data-id="<?php echo e($question->id); ?>">
                        <input type="text" value="<?php echo e($question->name); ?>" name="name"/>
                        <button>сохранить вопрос</button>
                    </form>
                </div>

                <div class="dd-handle question_handle" data-questionid=<?php echo e($question->id); ?>>
                </div>
        
                <ol class="dd-list">

                    <?php
                        $answers = $question->answers()->get()->sortBy(function ($item, $key) {
                            return $item->order;
                        });
                    ?>

                    <?php $__currentLoopData = $answers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                        <li class="dd-item answer-item" data-id="<?php echo e($answer->id); ?>">
                            <div class="pull-right item_actions">
                                <div class="btn btn-sm btn-danger pull-right answer_item_delete" data-id="<?php echo e($answer->id); ?>">
                                    <i class="voyager-trash"></i>
                                </div>
                            </div>
                            <div class="form-input pull-left">
                                    <form class="test-item-change" data-type="answer" data-id="<?php echo e($answer->id); ?>">
                                        <input type="text" value="<?php echo e($answer->name); ?>" name="name"/>
                                        <input type="checkbox" name="is_right" <?php if( $answer->is_right): ?> checked <?php endif; ?>/>
                                        <button>сохранить ответ</button>
                                    </form>
                                </div>
                            <div class="dd-handle">
                            </div>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ol>
            </li>
        
        
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
</ol>