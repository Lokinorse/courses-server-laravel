<section class="lp-section white padded glider-section" id="how-to-learn">
    <div class="lp-content">

        <h1 class="lp-h1">КАК ПРОХОДИТ <span>ОБУЧЕНИЕ</span></h1>

        <img src="{{asset("/img/jslp/howto-learn.png")}}"/>

    </div>
</section>
<section class="lp-section starter-section">
    <div class="lp-content">
        <a class="lp-cta-button" href="{{$program->getResumeUrl()}}" target="_blank" data-conversion="preview-learning"><i class="fa fa-play-circle"></i> СМОТРЕТЬ ПЛАТФОРМУ</a>
    </div>
</section>