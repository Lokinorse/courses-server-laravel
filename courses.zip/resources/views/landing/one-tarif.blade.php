<section class="lp-section white padded costs-section" id="costs">
	<div class="lp-content">
		
		<h1 class="lp-h1">АКЦИЯ <span>НА 20 000</span> РУБЛЕЙ</h1>


		<div class="costs-wrapper">
			

			<div class="costs-item-wrapper">
				<span class="round-corner-badge">-100%</span>
				<div class="cost-item-title-wrapper">
					<span class="cost-title">«Первопроходец»</span>
				</div>
				<b>Тебе:</b>
				
				<ul>
					<li>Все уроки программы</li>
					<li>Домашние задания</li>
					<li>Проверка заданий учителем</li>
					<li>Интерактивные тесты</li>
					<li>Вебинары</li>
					<li>Личные консультации</li>
					<li>Общение с другими учениками</li>
					<li>Сертификат об окончании</li>
				</ul>

				<div class="cost-price-wrapper">
					<strike class="old-price">20 000<i class="fa fa-ruble-sign"></i></strike>
					<span class="new-price">0<i class="fa fa-ruble-sign"></i></span>
				</div>
				<button class="cta-btn pay-submit" data-modaltrigger="vk-login" data-conversion="tarif-komfortniy">Начать обучение</button>
			</div>


		</div>

	</div>
</section>