<section class="lp-section blue padded resume-section" id="resume">
	<div class="lp-content">
		


		<div class="person-resume-wrapper">
			<div class="person-resume-box rippled">
				
				<h1 class="resume-header">ТВОЁ <span class="pinky">РЕЗЮМЕ</span> ПО ОКОНЧАНИЮ КУРСА</h1>

				<div class="resume-content">
					
					<div class="person-image">
						<img src="{{ asset('img/jslp/pavel.png') }}" alt="Ваше имя" />
					</div>

					<div class="person-description">
						<div class="person-name">Иван Иванов</div>
						<div class="person-badge">Javascript-разработчик</div>
						<div class="person-text">
							Опыт работы: менее 1 года
							<br/>
							<br/>
							Я умею использовать javascript для решения 
							fullstack-задач в веб-разработке. Люблю учиться
							и совершенствоваться в новых технологиях.
							<br/>
							<br/>
							Навыки:
							<br/>
							Верстка сайтов
							<br/>
							Мобильная адаптация
							<br/>
							Пользовательский интерактив и эффекты на сайте
							<br/>
							Работа с API
							<br/>
							Серверные решения
							<br/>
							<br/>
							Технологии:
							<br/>
							HTML5, CSS3, Javscript, jQuery, boostrap 4, Node.js, Express.js,  
							MongoDB, Mongoose, REST

						</div>
					</div>
				</div>
 
			</div>
		</div>

	</div>
</section>