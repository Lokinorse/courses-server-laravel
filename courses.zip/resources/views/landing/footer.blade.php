<footer>
	<div class="lp-content">
		<img class="white-logo" src="{{ asset('img/jslp/white-logo.png') }}" alt="Varilo.ru" />
		<div class="copyright">{{ now()->year }}г. Все права защищены. Любое копирование материалов сайта преследуется по закону.</div>
	</div>
</footer>