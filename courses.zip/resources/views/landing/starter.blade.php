<section class="lp-section starter-section">
	<div class="lp-content">
		<button class="lp-cta-button" data-modaltrigger="vk-login" data-conversion="starter-button"><i class="fa fa-play-circle"></i> Начать обучение</button>
	</div>



</section>