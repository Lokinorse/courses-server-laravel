

<!-- Yandex.Metrika counter -->
<script type="text/javascript" >
    (function(m,e,t,r,i,k,a){m[i]=m[i]||function(){(m[i].a=m[i].a||[]).push(arguments)};
    m[i].l=1*new Date();k=e.createElement(t),a=e.getElementsByTagName(t)[0],k.async=1,k.src=r,a.parentNode.insertBefore(k,a)})
    (window, document, "script", "https://mc.yandex.ru/metrika/tag.js", "ym");

    ym(51609848, "init", {
        clickmap:true,
        trackLinks:true,
        accurateTrackBounce:true,
        webvisor:true
    });
</script>
<noscript><div><img src="https://mc.yandex.ru/watch/51609848" style="position:absolute; left:-9999px;" alt="" /></div></noscript>
<!-- /Yandex.Metrika counter -->


<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-138684515-1"></script>
<script>
window.dataLayer = window.dataLayer || [];
function gtag(){dataLayer.push(arguments);}
gtag('js', new Date());

gtag('config', 'UA-138684515-1');
</script>

<script type="text/javascript">!function(){var t=document.createElement("script");t.type="text/javascript",t.async=!0,t.src="https://vk.com/js/api/openapi.js?160",t.onload=function(){VK.Retargeting.Init("VK-RTRG-317062-3gRde"),VK.Retargeting.Hit()},document.head.appendChild(t)}();</script><noscript><img src="https://vk.com/rtrg?p=VK-RTRG-317062-3gRde" style="position:fixed; left:-999px;" alt=""/></noscript>
<script src="https://vk.com/js/api/openapi.js?144"></script>  


<script>
VK.Retargeting.Init('VK-RTRG-317062-3gRde');  

var convert = window.convert = function (conversionName) {
    console.log(conversionName)
    if (conversionName.startsWith("tarif")) {
        window.selectedPlan = conversionName;
    }
    
    if (window.location.href.startsWith("http://courses")) return;
    if (!window.location.href.startsWith("https://varilo.ru")) return;
    ym(51609848, 'reachGoal', conversionName);
    VK.Retargeting.Event(conversionName)
}


$(document).on("click", "[data-conversion]", function(e) {
    var conversionName = $(this).data("conversion");
    window.convert(conversionName);
})


</script>
