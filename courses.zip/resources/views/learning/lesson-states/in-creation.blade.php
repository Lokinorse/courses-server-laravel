<div class="lesson-pane">
    <h5>В процессе переработки</h5>
    <div class="lesson-pane-content">
        Этот урок находится на стадии переработки.
    </div>
</div>